# IDT Client Reminder App v2
Android source project.
Features: offline saved records, installation/collection message drafts, edit/delete, schedule overview, installation notification 24h before, optional collection follow-up alarm.
Build: Android Studio > Open project > Gradle Sync > Build APK.
Date format YYYY-MM-DD; time HH:MM. WhatsApp draft must be sent manually.
Reminder behavior depends on Android notification and battery settings; test on device. This is source code, not a prebuilt APK.
