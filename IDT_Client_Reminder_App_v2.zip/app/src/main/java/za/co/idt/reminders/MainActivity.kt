package za.co.idt.reminders
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.activity.ComponentActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Job(val id:String=UUID.randomUUID().toString(),val client:String,val phone:String,val item:String,val address:String,val date:String,val time:String,val type:String,val notes:String="",val followDate:String="",val followTime:String="09:00"){
 fun json()=JSONObject().put("id",id).put("client",client).put("phone",phone).put("item",item).put("address",address).put("date",date).put("time",time).put("type",type).put("notes",notes).put("followDate",followDate).put("followTime",followTime)
 companion object{fun from(j:JSONObject)=Job(j.optString("id",UUID.randomUUID().toString()),j.optString("client"),j.optString("phone"),j.optString("item"),j.optString("address"),j.optString("date"),j.optString("time"),j.optString("type"),j.optString("notes"),j.optString("followDate"),j.optString("followTime","09:00"))}
}
class MainActivity:ComponentActivity(){
 val green=Color.rgb(140,255,0);val orange=Color.rgb(255,138,0);val dark=Color.rgb(16,18,18);val panel=Color.rgb(32,37,34)
 lateinit var root:LinearLayout;val jobs=mutableListOf<Job>()
 override fun onCreate(b:Bundle?){super.onCreate(b);val a=JSONArray(getSharedPreferences("idt",0).getString("jobs","[]"));for(i in 0 until a.length())jobs.add(Job.from(a.getJSONObject(i)));channel();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),1);home()}
 fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("idt_dates","IDT Reminders",NotificationManager.IMPORTANCE_HIGH))}
 fun save(){val a=JSONArray();jobs.forEach{a.put(it.json())};getSharedPreferences("idt",0).edit().putString("jobs",a.toString()).apply()}
 fun page(t:String){val s=ScrollView(this);root=LinearLayout(this).apply{orientation=1;setPadding(22,20,22,35);setBackgroundColor(dark)};s.addView(root);setContentView(s);label("I.D.T. STEELWORKS & ENGINEERING",21,green,true);label("CLIENT REMINDER SYSTEM",12,orange,true);label(t,20,Color.WHITE,true)}
 fun label(s:String,n:Int,c:Int,b:Boolean=false){root.addView(TextView(this).apply{text=s;textSize=n.toFloat();setTextColor(c);if(b)setTypeface(null,1);setPadding(0,8,0,8)})}
 fun btn(s:String,f:()->Unit){root.addView(Button(this).apply{text=s;setTextColor(Color.BLACK);setBackgroundColor(green);setOnClickListener{f()}})}
 fun field(s:String,h:String="",type:Int=InputType.TYPE_CLASS_TEXT,v:String=""):EditText{label(s,12,orange,true);return EditText(this).apply{hint=h;setText(v);inputType=type;setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);setSingleLine();setPadding(12,8,12,8);setBackgroundColor(panel);root.addView(this)}}
 fun home(){page("Dashboard");label("Installation bookings and collection notifications.",14,Color.LTGRAY);btn("＋ NEW INSTALLATION"){form("Installation")};btn("＋ READY FOR COLLECTION"){form("Collection")};btn("📆 CALENDAR / UPCOMING"){calendar()};btn("📋 ALL SAVED REMINDERS"){records()};label("UPCOMING",14,green,true);jobs.sortedBy{it.date+it.time}.take(5).forEach{label("${it.date} ${it.time} · ${it.client} · ${it.type}",13,Color.WHITE)};label("Saved: ${jobs.size}",13,orange)}
 fun form(type:String,old:Job?=null){page(if(old==null)"New $type" else "Edit ${old.type}");val c=field("CLIENT NAME","Client/company",v=old?.client?:"");val p=field("WHATSAPP NUMBER","27821234567",InputType.TYPE_CLASS_PHONE,old?.phone?:"");val item=field("ITEM / PROJECT","Gate, balustrade",v=old?.item?:"");val addr=field("ADDRESS","Installation address",v=old?.address?:"");val d=field("DATE (YYYY-MM-DD)","2026-11-20",v=old?.date?:"");val t=field("TIME (HH:MM)","09:00",v=old?.time?:"09:00");val note=field("NOTES","Optional",v=old?.notes?:"");val fd=field("COLLECTION FOLLOW-UP DATE (OPTIONAL)","YYYY-MM-DD",v=old?.followDate?:"");val ft=field("FOLLOW-UP TIME","09:00",v=old?.followTime?:"09:00")
 fun saveAnd(open:Boolean){if(c.text.isBlank()||p.text.isBlank()){toast("Client name and WhatsApp number required");return};val j=Job(old?.id?:UUID.randomUUID().toString(),c.text.toString(),p.text.toString().replace("+","").replace(" ",""),item.text.toString(),addr.text.toString(),d.text.toString(),t.text.toString(),type,note.text.toString(),fd.text.toString(),ft.text.toString());if(old!=null)jobs.removeAll{it.id==old.id};jobs.add(0,j);save();alarm(j,j.date,j.time,24,"Installation tomorrow","${j.client} · ${j.item}");if(j.followDate.isNotBlank())alarm(j,j.followDate,j.followTime,0,"Collection follow-up","Contact ${j.client} about ${j.item}");if(open)whatsapp(j);home()}
 btn("SAVE & DRAFT WHATSAPP"){saveAnd(true)};btn("SAVE ONLY"){saveAnd(false)};btn("BACK"){home()}}
 fun records(){page("Saved Reminders");if(jobs.isEmpty())label("No saved records.",14,Color.LTGRAY);jobs.toList().forEach{j->label("${j.type.uppercase()} · ${j.client}",16,green,true);label("${j.item}\n${j.date} ${j.time}\n${j.phone}\nCollection follow-up: ${j.followDate.ifBlank{"None"}}",13,Color.WHITE);btn("EDIT"){form(j.type,j)};btn("DRAFT WHATSAPP"){whatsapp(j)};btn("DELETE"){jobs.removeAll{x->x.id==j.id};save();records();return@forEach}};btn("BACK"){home()}}
 fun calendar(){page("Upcoming Calendar");val sorted=jobs.sortedBy{it.date+" "+it.time};if(sorted.isEmpty())label("Nothing scheduled.",14,Color.LTGRAY);sorted.forEach{j->label("📅 ${j.date} · ${j.time}",16,green,true);label("${j.client} — ${j.type}\n${j.item}\n${j.address}",13,Color.WHITE);btn("OPEN / EDIT"){form(j.type,j)}};btn("BACK"){home()}}
 fun message(j:Job)=if(j.type=="Installation")"Good day ${j.client},\n\nThis is a friendly reminder from I.D.T. Steelworks & Engineering regarding your upcoming installation.\n\n📅 Date: ${j.date}\n⏰ Time: ${j.time}\n📍 Address: ${j.address}\n🛠️ Project: ${j.item}\n\nKindly confirm that the scheduled date and time are convenient for you.\n\nRegards,\nI.D.T. Steelworks & Engineering" else "Good day ${j.client},\n\nYour items are ready for collection.\n\n📦 Items: ${j.item}\n\nPlease let us know when you would like to arrange collection.\n\nThank you for choosing I.D.T. Steelworks & Engineering.\n\nRegards,\nI.D.T. Steelworks & Engineering"
 fun whatsapp(j:Job){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/${j.phone}?text="+Uri.encode(message(j)))))}catch(e:Exception){toast("WhatsApp unavailable")}}
 fun alarm(j:Job,date:String,time:String,before:Int,title:String,body:String){try{val at=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse("$date $time")!!.time-before*3600000L;if(at<System.currentTimeMillis())return;val i=Intent(this,ReminderReceiver::class.java).putExtra("title",title).putExtra("body",body);val pi=PendingIntent.getBroadcast(this,(j.id+title).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val am=getSystemService(ALARM_SERVICE) as AlarmManager;if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)}catch(e:Exception){toast("Use date YYYY-MM-DD and time HH:MM")}}
 fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
