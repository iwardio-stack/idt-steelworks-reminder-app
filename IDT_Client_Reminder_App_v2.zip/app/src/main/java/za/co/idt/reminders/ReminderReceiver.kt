package za.co.idt.reminders
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val n=NotificationCompat.Builder(c,"idt_dates").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(i.getStringExtra("title")?:"IDT Reminder").setContentText(i.getStringExtra("body")?:"Upcoming client reminder").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();(c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis()%99999).toInt(),n)}}
