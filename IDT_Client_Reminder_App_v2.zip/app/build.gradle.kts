plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="za.co.idt.reminders"; compileSdk=35
 defaultConfig { applicationId="za.co.idt.reminders"; minSdk=26; targetSdk=35; versionCode=2; versionName="2.0" } }
dependencies { implementation("androidx.core:core-ktx:1.15.0") }
